import { createClient } from "@/lib/supabase/server"
import { redirect, notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"
import { Edit, MapPin, Calendar, Users, Heart } from "lucide-react"
import UserAvatar from "@/components/user-avatar"
import FollowButton from "@/components/follow-button"
import ProfileEditForm from "@/components/profile-edit-form"

interface ProfilePageProps {
  params: {
    username: string
  }
}

export default async function ProfilePage({ params }: ProfilePageProps) {
  console.log("[v0] Loading profile page for:", params.username)

  const supabase = createClient()
  if (!supabase) {
    redirect("/auth/login")
  }

  const {
    data: { user: currentUser },
  } = await supabase.auth.getUser()

  if (!currentUser) {
    redirect("/auth/login")
  }

  console.log("[v0] Looking for user with username:", params.username)

  // Handle special case for "me" username
  let profileUser
  if (params.username === "me") {
    console.log("[v0] Fetching current user profile")

    try {
      const { data, error } = await supabase.from("users").select("*").eq("id", currentUser.id).single()
      if (error) {
        console.log("[v0] Custom users table not available, using auth data")
        // Fallback to auth user data
        profileUser = {
          id: currentUser.id,
          email: currentUser.email,
          username: currentUser.user_metadata?.username || "me",
          full_name: currentUser.user_metadata?.full_name || "User",
          bio: null,
          avatar_url: null,
          gender: currentUser.user_metadata?.gender || "other",
          is_online: false,
          created_at: currentUser.created_at,
        }
      } else {
        profileUser = data
      }
    } catch (error) {
      console.error("[v0] Error fetching profile, using auth fallback:", error)
      profileUser = {
        id: currentUser.id,
        email: currentUser.email,
        username: currentUser.user_metadata?.username || "me",
        full_name: currentUser.user_metadata?.full_name || "User",
        bio: null,
        avatar_url: null,
        gender: currentUser.user_metadata?.gender || "other",
        is_online: false,
        created_at: currentUser.created_at,
      }
    }
  } else {
    try {
      const { data, error } = await supabase.from("users").select("*").eq("username", params.username).single()
      if (error) {
        console.log("[v0] User not found in custom table")
        notFound()
      }
      profileUser = data
    } catch (error) {
      console.error("[v0] Error fetching user profile:", error)
      notFound()
    }
  }

  if (!profileUser) {
    console.log("[v0] Profile user not found")
    notFound()
  }

  console.log("[v0] Found profile user:", profileUser.username)

  const isOwnProfile = currentUser.id === profileUser.id

  let followersCount = 0
  let followingCount = 0
  let isFollowing = false
  let postsCount = 0

  try {
    const { count: followers } = await supabase
      .from("followers")
      .select("*", { count: "exact", head: true })
      .eq("following_id", profileUser.id)
    followersCount = followers || 0

    const { count: following } = await supabase
      .from("followers")
      .select("*", { count: "exact", head: true })
      .eq("follower_id", profileUser.id)
    followingCount = following || 0

    // Check if current user follows this profile
    const { data: followRelation } = await supabase
      .from("followers")
      .select("id")
      .eq("follower_id", currentUser.id)
      .eq("following_id", profileUser.id)
      .single()
    isFollowing = !!followRelation

    // Get user's posts count
    const { count: posts } = await supabase
      .from("posts")
      .select("*", { count: "exact", head: true })
      .eq("user_id", profileUser.id)
    postsCount = posts || 0
  } catch (error) {
    console.log("[v0] Social features not available (tables may not exist)")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-purple-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Heart className="h-6 w-6 text-pink-500" />
              <h1 className="text-xl font-bold bg-gradient-to-r from-pink-600 to-violet-600 bg-clip-text text-transparent">
                Echo
              </h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg mb-8">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row items-start md:items-center space-y-6 md:space-y-0 md:space-x-8">
              <div className="relative">
                <UserAvatar
                  src={profileUser.avatar_url}
                  alt={profileUser.username}
                  fallback={profileUser.username?.charAt(0).toUpperCase()}
                  size="xl"
                  className="ring-4 ring-pink-100"
                />
                {profileUser.is_online && (
                  <div className="absolute -bottom-2 -right-2 h-6 w-6 bg-green-500 border-4 border-white rounded-full"></div>
                )}
              </div>

              <div className="flex-1">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
                  <div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-1">
                      {profileUser.full_name || profileUser.username}
                    </h1>
                    <p className="text-lg text-gray-500">@{profileUser.username}</p>
                  </div>
                  <div className="flex space-x-3 mt-4 sm:mt-0">
                    {isOwnProfile ? (
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="outline"
                            className="border-pink-200 hover:bg-pink-50 text-pink-600 bg-transparent"
                          >
                            <Edit className="h-4 w-4 mr-2" />
                            Edit Profile
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-md">
                          <ProfileEditForm user={profileUser} />
                        </DialogContent>
                      </Dialog>
                    ) : (
                      <FollowButton userId={profileUser.id} isFollowing={isFollowing} />
                    )}
                  </div>
                </div>

                {profileUser.bio && <p className="text-gray-700 mb-4 text-lg leading-relaxed">{profileUser.bio}</p>}

                <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 mb-6">
                  {profileUser.location && (
                    <div className="flex items-center space-x-1">
                      <MapPin className="h-4 w-4" />
                      <span>{profileUser.location}</span>
                    </div>
                  )}
                  {profileUser.gender && (
                    <Badge variant="secondary" className="text-sm">
                      {profileUser.gender}
                    </Badge>
                  )}
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-4 w-4" />
                    <span>Joined {new Date(profileUser.created_at).toLocaleDateString()}</span>
                  </div>
                </div>

                {/* Stats */}
                <div className="flex space-x-8">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{postsCount || 0}</div>
                    <div className="text-sm text-gray-500">Posts</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{followersCount || 0}</div>
                    <div className="text-sm text-gray-500">Followers</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{followingCount || 0}</div>
                    <div className="text-sm text-gray-500">Following</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Posts Grid - Coming Soon */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Posts Coming Soon</h3>
            <p className="text-gray-600">
              {isOwnProfile
                ? "Your posts will appear here once you start sharing!"
                : `${profileUser.username}'s posts will appear here.`}
            </p>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
