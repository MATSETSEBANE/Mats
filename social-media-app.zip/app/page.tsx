import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Heart, Video, MessageCircle, Users, TrendingUp, Zap } from "lucide-react"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default async function HomePage() {
  const supabase = createClient()
  if (!supabase) {
    redirect("/auth/login")
  }

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("users").select("*").eq("id", user.id).single()

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-indigo-50">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-6">
              Welcome to Echo
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              The ultimate social platform where you can connect through random video calls, share reels, chat with
              friends, and chill in virtual rooms
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link href="/video-chat">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  <Video className="h-5 w-5 mr-2" />
                  Start Video Chat
                </Button>
              </Link>
              <Link href="/reels">
                <Button size="lg" variant="outline">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  Explore Reels
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          <Card className="text-center p-6 bg-white/80 backdrop-blur-sm">
            <CardContent className="p-0">
              <div className="text-3xl font-bold text-purple-600 mb-2">1.2K+</div>
              <div className="text-sm text-gray-600">Active Users</div>
            </CardContent>
          </Card>
          <Card className="text-center p-6 bg-white/80 backdrop-blur-sm">
            <CardContent className="p-0">
              <div className="text-3xl font-bold text-pink-600 mb-2">5.8K+</div>
              <div className="text-sm text-gray-600">Video Calls</div>
            </CardContent>
          </Card>
          <Card className="text-center p-6 bg-white/80 backdrop-blur-sm">
            <CardContent className="p-0">
              <div className="text-3xl font-bold text-indigo-600 mb-2">12K+</div>
              <div className="text-sm text-gray-600">Messages Sent</div>
            </CardContent>
          </Card>
          <Card className="text-center p-6 bg-white/80 backdrop-blur-sm">
            <CardContent className="p-0">
              <div className="text-3xl font-bold text-emerald-600 mb-2">350+</div>
              <div className="text-sm text-gray-600">Chill Rooms</div>
            </CardContent>
          </Card>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <Link href="/video-chat" className="group">
            <Card className="h-full bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 group-hover:scale-105">
              <CardContent className="p-8 text-center">
                <div className="bg-gradient-to-r from-purple-500 to-violet-500 p-4 rounded-full w-fit mx-auto mb-6">
                  <Video className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Random Video Calls</h3>
                <p className="text-gray-600 mb-4">
                  Connect with people of different genders through random video chats
                </p>
                <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                  <Zap className="h-3 w-3 mr-1" />
                  Live Now
                </Badge>
              </CardContent>
            </Card>
          </Link>

          <Link href="/reels" className="group">
            <Card className="h-full bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 group-hover:scale-105">
              <CardContent className="p-8 text-center">
                <div className="bg-gradient-to-r from-pink-500 to-rose-500 p-4 rounded-full w-fit mx-auto mb-6">
                  <TrendingUp className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Reels & Stories</h3>
                <p className="text-gray-600 mb-4">Share your moments with engaging short videos and get discovered</p>
                <Badge variant="secondary" className="bg-pink-100 text-pink-700">
                  Trending
                </Badge>
              </CardContent>
            </Card>
          </Link>

          <Link href="/chat" className="group">
            <Card className="h-full bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 group-hover:scale-105">
              <CardContent className="p-8 text-center">
                <div className="bg-gradient-to-r from-blue-500 to-cyan-500 p-4 rounded-full w-fit mx-auto mb-6">
                  <MessageCircle className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Real-time Chat</h3>
                <p className="text-gray-600 mb-4">
                  Stay connected with friends through instant messaging and group chats
                </p>
                <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                  Instant
                </Badge>
              </CardContent>
            </Card>
          </Link>

          <Link href="/rooms" className="group">
            <Card className="h-full bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 group-hover:scale-105">
              <CardContent className="p-8 text-center">
                <div className="bg-gradient-to-r from-emerald-500 to-teal-500 p-4 rounded-full w-fit mx-auto mb-6">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Chilling Rooms</h3>
                <p className="text-gray-600 mb-4">Join themed virtual hangout spaces and meet like-minded people</p>
                <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                  Social
                </Badge>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Welcome Message */}
        <Card className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
          <CardContent className="p-12 text-center">
            <Heart className="h-16 w-16 mx-auto mb-6 opacity-80" />
            <h2 className="text-3xl font-bold mb-4">
              Welcome back, {profile?.full_name || profile?.username || "Friend"}!
            </h2>
            <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto">
              Your social universe awaits. Connect, share, and discover amazing experiences with people from around the
              world.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link href="/discover">
                <Button size="lg" variant="secondary">
                  Discover People
                </Button>
              </Link>
              <Link href={`/profile/${profile?.username}`}>
                <Button
                  size="lg"
                  variant="outline"
                  className="bg-transparent border-white text-white hover:bg-white hover:text-purple-600"
                >
                  View Profile
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
