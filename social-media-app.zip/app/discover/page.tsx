import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Search, Users, Heart } from "lucide-react"
import UserCard from "@/components/user-card"

interface DiscoverPageProps {
  searchParams: {
    q?: string
  }
}

export default async function DiscoverPage({ searchParams }: DiscoverPageProps) {
  const supabase = createClient()
  if (!supabase) {
    redirect("/auth/login")
  }

  const {
    data: { user: currentUser },
  } = await supabase.auth.getUser()

  if (!currentUser) {
    redirect("/auth/login")
  }

  const searchQuery = searchParams.q || ""

  // Get users based on search or show all
  let usersQuery = supabase
    .from("users")
    .select("*")
    .neq("id", currentUser.id)
    .order("created_at", { ascending: false })
    .limit(20)

  if (searchQuery) {
    usersQuery = usersQuery.or(`username.ilike.%${searchQuery}%,full_name.ilike.%${searchQuery}%`)
  }

  const { data: users } = await usersQuery

  // Get following relationships for current user
  const { data: followingData } = await supabase
    .from("followers")
    .select("following_id")
    .eq("follower_id", currentUser.id)

  const followingIds = followingData?.map((f) => f.following_id) || []

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-purple-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Heart className="h-6 w-6 text-pink-500" />
              <h1 className="text-xl font-bold bg-gradient-to-r from-pink-600 to-violet-600 bg-clip-text text-transparent">
                SocialVibe
              </h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Header */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Users className="h-6 w-6 text-pink-500" />
              <span>Discover People</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form method="GET" className="flex space-x-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  name="q"
                  placeholder="Search by username or name..."
                  defaultValue={searchQuery}
                  className="pl-10 border-gray-200 focus:border-pink-400 focus:ring-pink-400"
                />
              </div>
              <Button
                type="submit"
                className="bg-gradient-to-r from-pink-500 to-violet-500 hover:from-pink-600 hover:to-violet-600 text-white"
              >
                Search
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Results */}
        {searchQuery && (
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              {users?.length ? `Found ${users.length} users` : "No users found"} for "{searchQuery}"
            </h2>
          </div>
        )}

        {/* Users Grid */}
        {users && users.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {users.map((user) => (
              <UserCard
                key={user.id}
                user={user}
                currentUserId={currentUser.id}
                isFollowing={followingIds.includes(user.id)}
              />
            ))}
          </div>
        ) : (
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-12 text-center">
              <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {searchQuery ? "No users found" : "No users to discover"}
              </h3>
              <p className="text-gray-600">
                {searchQuery
                  ? "Try searching with different keywords"
                  : "Be the first to invite your friends to join SocialVibe!"}
              </p>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  )
}
