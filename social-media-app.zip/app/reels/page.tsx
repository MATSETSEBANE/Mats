import { ReelsFeed } from "@/components/reels-feed"
import { ReelUpload } from "@/components/reel-upload"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ReelsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <Tabs defaultValue="feed" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="feed">Reels Feed</TabsTrigger>
          <TabsTrigger value="upload">Upload Reel</TabsTrigger>
        </TabsList>

        <TabsContent value="feed">
          <ReelsFeed />
        </TabsContent>

        <TabsContent value="upload">
          <div className="flex justify-center">
            <ReelUpload />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
